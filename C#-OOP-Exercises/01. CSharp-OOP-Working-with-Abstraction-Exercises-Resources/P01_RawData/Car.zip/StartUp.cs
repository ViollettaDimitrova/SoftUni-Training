﻿namespace P01_RawData
{
    class StartUp
    {
        static void Main()
        {
            Runner runner = new Runner();
            runner.Run();
        }
    }
}
